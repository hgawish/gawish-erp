﻿using GawishERP.Domain.Common;

namespace GawishERP.Domain.Entities;

public sealed class PostingProfile : BaseEntity
{
    public string Code { get; private set; } = string.Empty;

    public string Name { get; private set; } = string.Empty;

    public DocumentType DocumentType { get; private set; }

    public Guid DebitAccountId { get; private set; }

    public Guid CreditAccountId { get; private set; }

    public CashFlowCategory CashFlowCategory { get; private set; }

    public bool IsActive { get; private set; }

    //=====================================
    // Navigation
    //=====================================

    public Account DebitAccount { get; private set; } = null!;

    public Account CreditAccount { get; private set; } = null!;

    private PostingProfile()
    {
    }

    public PostingProfile(
        string code,
        string name,
        DocumentType documentType,
        Guid debitAccountId,
        Guid creditAccountId,
        CashFlowCategory cashFlowCategory = CashFlowCategory.None)
    {
        if (string.IsNullOrWhiteSpace(code))
            throw new ArgumentException(nameof(code));

        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException(nameof(name));

        if (debitAccountId == Guid.Empty)
            throw new ArgumentException(nameof(debitAccountId));

        if (creditAccountId == Guid.Empty)
            throw new ArgumentException(nameof(creditAccountId));

        Code = code;

        Name = name;

        DocumentType = documentType;

        DebitAccountId = debitAccountId;

        CreditAccountId = creditAccountId;

        CashFlowCategory = cashFlowCategory;

        IsActive = true;
    }

    public void Update(
        string name,
        Guid debitAccountId,
        Guid creditAccountId,
        CashFlowCategory cashFlowCategory)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException(nameof(name));

        Name = name;

        DebitAccountId = debitAccountId;

        CreditAccountId = creditAccountId;

        CashFlowCategory = cashFlowCategory;
    }

    public void SetCashFlowCategory(
        CashFlowCategory category)
    {
        CashFlowCategory = category;
    }

    public void Activate()
    {
        IsActive = true;
    }

    public void Deactivate()
    {
        IsActive = false;
    }
}