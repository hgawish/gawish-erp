﻿using GawishERP.Domain.Common;

namespace GawishERP.Application.Common.Posting;

public sealed class PostingContext
{
    public Guid DocumentId { get; init; }

    public DocumentType DocumentType { get; init; }

    public string DocumentNumber { get; init; } = string.Empty;

    public DateTime PostingDate { get; init; }

    public Guid FiscalYearId { get; init; }

    public Guid? CompanyId { get; init; }

    public Guid? BranchId { get; init; }

    public string? ReferenceNumber { get; init; }

    public string? Description { get; init; }

    public decimal Amount { get; init; }

    public IReadOnlyCollection<PostingLineContext> Lines { get; init; }
        = Array.Empty<PostingLineContext>();
}

public sealed class PostingLineContext
{
    public Guid ProductId { get; init; }

    public Guid? WarehouseId { get; init; }

    public decimal Quantity { get; init; }

    public decimal UnitPrice { get; init; }

    public decimal LineAmount => Quantity * UnitPrice;

    public string? BatchNumber { get; init; }

    public DateTime? ExpiryDate { get; init; }

    public string? Description { get; init; }
}