﻿namespace GawishERP.Application.Common.Posting;

public sealed class AccountResolutionResult
{
    public Guid DebitAccountId { get; init; }

    public Guid CreditAccountId { get; init; }

    public decimal DebitAmount { get; init; }

    public decimal CreditAmount { get; init; }

    public string Description { get; init; } = string.Empty;
}