﻿using GawishERP.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GawishERP.Infrastructure.Persistence.Configurations;

public sealed class PostingProfileConfiguration
    : IEntityTypeConfiguration<PostingProfile>
{
    public void Configure(EntityTypeBuilder<PostingProfile> builder)
    {
        builder.ToTable("PostingProfiles");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Code)
            .HasMaxLength(50)
            .IsRequired();

        builder.HasIndex(x => x.Code)
            .IsUnique();

        builder.Property(x => x.Name)
            .HasMaxLength(200)
            .IsRequired();

        builder.Property(x => x.DocumentType)
            .HasConversion<int>()
            .IsRequired();

        // NEW
        builder.Property(x => x.CashFlowCategory)
            .HasConversion<int>()
            .IsRequired();

        builder.Property(x => x.IsActive)
            .IsRequired();

        builder.HasOne(x => x.DebitAccount)
            .WithMany()
            .HasForeignKey(x => x.DebitAccountId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(x => x.CreditAccount)
            .WithMany()
            .HasForeignKey(x => x.CreditAccountId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}